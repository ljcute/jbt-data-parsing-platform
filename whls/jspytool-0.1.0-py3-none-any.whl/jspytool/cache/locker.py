# -*- coding: utf-8 -*-
import uuid
import math
import time
from jspytool.cache import get_redis, create_key

__all__ = ['acquire_lock', 'release_lock', 'expire_lock']


def acquire_lock(lock_name, acquire_timeout=3.0, lock_expire_seconds=60):
    """
    基于 Redis 实现的分布式锁
    :param lock_name: <str> 锁的名称
    :param acquire_timeout: <float> 获取锁的超时时间，默认 3 秒
    :param lock_expire_seconds: <int> 锁的超时时间，默认 60 秒
    :return: <str> 锁标识符
    """
    redis = get_redis()
    identifier = str(uuid.uuid4())
    key = create_key('locker', lock_name)
    lock_expire_seconds = int(math.ceil(lock_expire_seconds))

    end = time.time() + acquire_timeout

    while time.time() < end:
        # 如果不存在这个锁则加锁并设置过期时间，避免死锁
        if redis.set(key, identifier, ex=lock_expire_seconds, nx=True):
            redis.close()
            return identifier

        time.sleep(0.001)
    redis.close()
    return False


def release_lock(lock_name, identifier):
    """
    释放锁
    :param lock_name: <str> 锁的名称
    :param identifier: <str> 锁的标识
    :return: <bool>
    """
    unlock_script = """
    if redis.call("get",KEYS[1]) == ARGV[1] then
        return redis.call("del",KEYS[1])
    else
        return 0
    end
    """
    redis = get_redis()
    key = create_key('locker', lock_name)
    unlock = redis.register_script(unlock_script)
    result = unlock(keys=[key], args=[identifier])
    redis.close()
    return True if result else False


def expire_lock(lock_name, identifier, expire_seconds=60):
    """
    设置锁失效
    :param lock_name: <str> 锁的名称
    :param identifier: <str> 锁的标识
    :param expire_seconds: <int> 锁失效时间，单位：秒
    :return: <bool>
    """
    expire_script = """
    if redis.call("get",KEYS[1]) == ARGV[1] then
        return redis.call("expire",KEYS[1],ARGV[2])
    else
        return 0
    end
    """
    redis = get_redis()
    key = create_key('locker', lock_name)
    expire_key = redis.register_script(expire_script)
    result = expire_key(keys=[key], args=[identifier, expire_seconds])
    redis.close()
    return True if result else False
