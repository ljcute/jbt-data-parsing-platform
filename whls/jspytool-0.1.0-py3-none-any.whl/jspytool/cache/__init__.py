# -*- coding: utf-8 -*-
import redis

__all__ = ['init_redis_pool', 'get_redis', 'create_key']

# redis连接池
redis_pool = None
# redis缓存key前缀配置
redis_key_prefix = None
# 是否集群环境
is_cluster = False


def init_redis_pool(redis_cfg, key_prefix='jspy'):
    """
    初始化连接池
    :param redis_cfg:<dict> redis连接池配置对象，格式举例：
        单机模式：{
            "db": 1, "host": "127.0.0.1", "port": 6379, "password": "xxx", "max_connections": 8
        }
        集群模式：{
            "password": "xxx", "max_connections": 8,
            "cluster": {
                "nodes": "172.16.10.51:6379,172.16.10.51:6380,172.16.10.51:6381",
                "max_connections_per_node": False
            }
        }
    :param key_prefix:<str> Redis key前缀，例如：pypra:**
    :return:<none>
    """
    global redis_pool
    global redis_key_prefix
    global is_cluster
    if redis_pool is None:
        cluster = redis_cfg.get('cluster')
        if cluster:
            from rediscluster import ClusterConnectionPool
            is_cluster = True
            nodes = cluster['nodes'].split(',')
            startup_nodes = [{'host': i.split(':')[0], 'port': int(i.split(':')[1])} for i in nodes]
            max_con_per_node = cluster.get('max_connections_per_node', False)
            _copy_cfg = redis_cfg.copy()
            del _copy_cfg['cluster']
            redis_pool = ClusterConnectionPool(startup_nodes=startup_nodes, max_connections_per_node=max_con_per_node,
                                               **_copy_cfg)
        else:
            redis_pool = redis.ConnectionPool(**redis_cfg)
        redis_key_prefix = key_prefix


def get_redis():
    """
    从连接池获取一个redis对象
    :return:
    """
    global redis_pool
    if redis_pool is None:
        raise ConnectionError('redis连接池还未初始化，请先执行初始化操作')
    if is_cluster:
        from rediscluster import RedisCluster
        return RedisCluster(connection_pool=redis_pool)
    else:
        return redis.Redis(connection_pool=redis_pool)


def create_key(*keys):
    """
    生成带层级的redis key
    :param keys: <tuple>，例如：create_key('sharp', '9R')，将返回字符串：'pypra:sharp:9R'
    :return:
    """
    return f'{redis_key_prefix}:' + ':'.join(keys)
