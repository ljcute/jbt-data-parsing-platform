# -*- coding: utf-8 -*-
import abc
import datetime
import pickle
import threading
import pandas as pd
from jspytool import logger
from jspytool.util.exception import BizException
from jspytool.util.date_util import get_today, get_offset_day, date_to_int
from jspytool.util.wrapper import retry
from jspytool.cache import get_redis, create_key


"""
时间序列缓存
"""


class TimeSeriesFetcher(metaclass=abc.ABCMeta):
    """
    时间序列
    """

    @abc.abstractmethod
    def fetch(self, start_dt, end_dt):
        """
        查询指定时间范围的数据
        :param start_dt: <datetime> 起始时间
        :param end_dt: <datetime> 结束时间
        :return: <dataframe> 时间序列结果（不能返回None），
        index为日期索引，建议返回类型为int，支持格式如：20201201、'2020-11-01'、datetime(2020, 11, 1)
        """
        pass

    @abc.abstractmethod
    def get_cache_name(self):
        """
        返回缓存名称，示例：AIndexDailyPctChange:000300.SH
        :return: <str> 缓存名称
        """
        pass


def build_ts_key(name):
    """
    根据指定的缓存名称构造redis中的缓存key，最终的key = 'prefix:ts:'+name
    :param name: 时间序列缓存名称
    :return:
    """
    return create_key('ts', name)


def get_cache_name(redis_key):
    """
    根据redis key解析缓存名称
    :param redis_key:<str> redis key
    :return : <str> 缓存名称
    """
    prefix = create_key('ts')
    return redis_key.replace(prefix + ':', '')


def serialize_row(dt_int, row_series):
    """
    序列化数据行
    :param dt_int: <int> 日期，格式如：20200101
    :param row_series: <pandas.Series> 行数据
    :return: <bytes> 序列化串
    """
    row = row_series.append(pd.Series([int(dt_int)], index=['jspy_ts_row_dt']))
    return pickle.dumps(row)


def deserialize_row(row_bytes):
    """
    反序列化数据行
    :param row_bytes: <bytes> 序列化串
    :return: <datetime>, <pandas.Series> 日期 + 行数据
    """
    row_series = pickle.loads(row_bytes)
    dt_int = row_series.pop('jspy_ts_row_dt')
    return int(dt_int), row_series


def serialize_number_row(dt_int, row_series):
    """
    序列化纯数字的数据行
    :param dt_int: <int> 日期，格式如：20200101
    :param row_series: <pandas.Series> 行数据
    :return: <bytes> 序列化串
    """
    # 序列化格式：date|value1,value2,value3,...,valueN
    _dt_str = str(dt_int)
    _ser = _dt_str + '|' + ','.join(list(str(i) for i in row_series))
    return _ser.encode('utf8')


def deserialize_number_row(row_str_bytes):
    """
    反序列化纯数字的数据行
    :param row_str_bytes: <bytes> 序列化串
    :return: <datetime>, <pandas.Series> 日期 + 行数据
    """
    v = row_str_bytes.decode('utf8')
    dt_int = int(v[:v.index('|')])
    arr = v[v.index('|') + 1:].split(',')
    arr = list(float(i) if (i != 'None' and i != '') else None for i in arr)
    return dt_int, pd.Series(arr)


def delete_time_series_cache(name):
    """
    删除指定name的时间序列缓存
    :param name: <str> 缓存名称
    """
    r, k = get_redis(), build_ts_key(name)
    r.delete(k)
    r.close()


def delete_time_series_cache_value(name, start_dt, end_dt):
    """
    删除指定name的时间序列缓存
    :param name: <str> 缓存名称
    :param start_dt: <datetime|str|int> 起始日期
    :param end_dt: <datetime|str|int> 结束日期
    """
    min_score = date_to_int(start_dt)
    max_score = date_to_int(end_dt)
    if min_score > max_score:
        raise BizException('非法参数：start_dt > end_dt')
    r, k = get_redis(), build_ts_key(name)
    r.zremrangebyscore(k, min_score, max_score)
    r.close()


def query_time_series_by_count(name, end_dt, count, fetcher=None,
                               serializer=serialize_number_row, deserializer=deserialize_number_row):
    """
    查询指定日期历史时间序列数据
    :param name: <str> 缓存名称
    :param end_dt: <datetime|str> 查询截止日期
    :param count: <int> 往历史查询多少条记录
    :param fetcher: <TimeSeriesFetcher> 取数器，当缓存中不存在时，尝试执行取数器查询数据，并缓存到redis
    :param serializer: <func> 行数据序列化函数
    :param deserializer: <func> 行数据反序列化函数
    :return: <dataframe> 时间序列结果，index type: datetime，column type：float
    """
    logger.debug(f'执行时间序列缓存查询接口，name={name}, end_dt={end_dt}, count={count}')
    end_dt = datetime.datetime.strptime(str(date_to_int(end_dt)), '%Y%m%d')
    # 计算起始日期
    start_dt = end_dt - datetime.timedelta(days=count - 1)

    return query_time_series_by_range(name, start_dt, end_dt, fetcher, serializer, deserializer)


@retry(attempt=1, delay_seconds=0.1)
def query_time_series_by_range(name, start_dt, end_dt, fetcher=None,
                               serializer=serialize_number_row, deserializer=deserialize_number_row):
    """
    查询指定日期范围序列数据
    :param name: <str> 缓存名称
    :param start_dt: <datetime|str> 查询起始日期
    :param end_dt: <datetime|str> 查询截止日期
    :param fetcher: <TimeSeriesFetcher> 取数器，当缓存中不存在时，尝试执行取数器查询数据，并缓存到redis
    :param serializer: <func> 行数据序列化函数
    :param deserializer: <func> 行数据反序列化函数
    :return: <dataframe> 时间序列结果，index type: datetime，column type：float
    """
    logger.debug(f'执行时间序列缓存查询接口，name={name}, start_dt={start_dt}, end_dt={end_dt}')
    # 日期条件转换为redis缓存分数
    min_score, max_score = date_to_int(start_dt), date_to_int(end_dt)

    # 参数校验
    if min_score > max_score:
        raise BizException('非法参数：start_dt > end_dt')

    # 获取redis连接
    r, k = get_redis(), build_ts_key(name)
    try:
        # 查询缓存，返回值格式：[(b'v1', 20200101), (b'v2', 20200102), (b'v3', 20200103)]
        data = r.zrangebyscore(k, min=min_score, max=max_score, withscores=True, score_cast_func=int)
        data = [] if data is None else data

        columns = []
        if fetcher is not None:
            # 计算需要补数据的时间区间
            days = __list_dt_range(min_score, max_score)
            supply_dts = __calc_supply_date_range(data, days)
            if len(supply_dts) > 0:
                # 需要补数据
                for _s, _e in supply_dts:
                    _s_dt = datetime.datetime.strptime(str(_s), '%Y%m%d')
                    _e_dt = datetime.datetime.strptime(str(_e), '%Y%m%d')
                    df = fetcher.fetch(_s_dt, _e_dt)
                    # 提取列名
                    columns = list(df.columns)
                    # 有数据的dt
                    _has_data_dts = set()
                    if len(df.index) > 0:
                        for i in range(len(df.index)):
                            _dt = df.index[i]
                            _ser = df.iloc[i, :]
                            # 序列化，格式示例：date|value1,value2,value3,...,valueN
                            _score = date_to_int(_dt)
                            _value = serializer(_score, _ser)
                            # 添加到缓存
                            r.zadd(k, {_value: _score}, nx=True)
                            # 添加到结果集
                            data.append((_value, _score))
                            _has_data_dts.add(_score)

                    # 无数据的日期，补：None
                    _dt_int_range = days[days.index(_s):days.index(_e) + 1]
                    for _dt_int in _dt_int_range:
                        if _dt_int not in _has_data_dts:
                            # 序列化，格式示例：date|None,None,...,None
                            _ser = pd.Series(list(None for i in columns), index=columns)
                            _score = _dt_int
                            _value = serializer(_score, _ser)
                            # 添加到缓存
                            r.zadd(k, {_value: _score}, nx=True)
                            # 添加到结果集
                            data.append((_value, _score))
                # 添加列名定义到第一个索引位置
                if len(columns) > 0:
                    r.zadd(k, {','.join(columns): 0}, nx=True)
        # 获取列名
        if len(columns) == 0:
            _cols = r.zrangebyscore(k, min=0, max=0)
            columns = _cols[0].decode().split(',') if _cols else columns

        # 构造结果集
        index = []
        values = []
        for i in data:
            # 反序列化，格式示例：[(b'20200101|0.12,2.3,0.5', 20200101), (b'20200102|0.05,1.45,2.55', 20200102)]
            _dt, _ser = deserializer(i[0])
            index.append(_dt)
            values.append(_ser)

        # 释放redis连接
        r.close()

        df = pd.DataFrame(data=values, index=index).sort_index()
        # 从缓存中反序列化的列与源数据列不匹配时，以源数据列为准
        c_cols = list(df.columns)
        c_cols.sort()
        r_cols = list(columns)
        r_cols.sort()
        if str(c_cols) != str(r_cols) and len(columns) > 0:
            df.columns = columns
        return df
    except Exception as ex:
        logger.error("时间序列缓存查询错误 key:%s, error:%s", k, ex)
        # 删除损坏的缓存数据，抛出异常并重试@retry
        r.zremrangebyscore(k, 0, 0)
        r.zremrangebyscore(k, min_score, max_score)
        raise ex


def query_multi_time_series_by_range(fetchers, start_dt, end_dt, serializer=serialize_number_row,
                                     deserializer=deserialize_number_row):
    """
    查询指定日期范围序列数据
    :param fetchers: <list<TimeSeriesFetcher>> 缓存取数器列表
    :param start_dt: <datetime|str> 查询起始日期
    :param end_dt: <datetime|str> 查询截止日期
    :param serializer: <func> 行数据序列化函数
    :param deserializer: <func> 行数据反序列化函数
    :return: <dict<TimeSeriesFetcher, dataframe>> 时间序列结果，key为取数器，value为查询结果DataFrame
    """
    # 提取缓存名称列表
    names = list(f.get_cache_name() for f in fetchers)
    name_fetch_map = {f.get_cache_name(): f for f in fetchers}
    logger.debug(f'执行时间序列缓存批量查询接口，names={names}, start_dt={start_dt}, end_dt={end_dt}')
    # 日期条件转换为redis缓存分数
    min_score, max_score = date_to_int(start_dt), date_to_int(end_dt)

    # 参数校验
    if min_score > max_score:
        raise BizException('非法参数：start_dt > end_dt')

    # 日历列表
    days = __list_dt_range(min_score, max_score)

    # 获取redis连接
    r = get_redis()

    # 查询缓存，返回值格式：[(b'v1', 20200101), (b'v2', 20200102), (b'v3', 20200103)]
    res_map = {}
    data_map = query_raw_multi_time_series_by_score(names, min_score, max_score)

    columns = []
    for name in data_map:
        k = build_ts_key(name)
        fetcher = name_fetch_map[name]
        # 添加缓存结果
        _sub_data = data_map.get(name, [])[1:]

        # 计算需要补数据的时间区间
        supply_dts = __calc_supply_date_range(_sub_data, days)
        if len(supply_dts) > 0:
            # 需要补数据
            for _s, _e in supply_dts:
                _s_dt = datetime.datetime.strptime(str(_s), '%Y%m%d')
                _e_dt = datetime.datetime.strptime(str(_e), '%Y%m%d')
                df = fetcher.fetch(_s_dt, _e_dt)
                # 提取列名
                columns = list(df.columns)
                # 有数据的dt
                _has_data_dts = set()
                if len(df.index) > 0:
                    for i in range(len(df.index)):
                        _dt = df.index[i]
                        _ser = df.iloc[i, :]
                        # 序列化，格式示例：date|value1,value2,value3,...,valueN
                        _score = date_to_int(_dt)
                        _value = serializer(_score, _ser)
                        # 添加到缓存
                        r.zadd(k, {_value: _score}, nx=True)
                        # 添加到结果集
                        _sub_data.append((_value, _score))
                        _has_data_dts.add(_score)

                # 无数据的日期，补：None
                _dt_int_range = days[days.index(_s):days.index(_e)+1]
                for _dt_int in _dt_int_range:
                    if _dt_int not in _has_data_dts:
                        # 序列化，格式示例：date|None,None,...,None
                        _ser = pd.Series(list(None for i in columns), index=columns)
                        _score = _dt_int
                        _value = serializer(_score, _ser)
                        # 添加到缓存
                        r.zadd(k, {_value: _score}, nx=True)
                        # 添加到结果集
                        _sub_data.append((_value, _score))
            # 添加列名定义到第一个索引位置
            if len(columns) > 0:
                r.zadd(k, {','.join(columns): 0}, nx=True)
        # 获取列名
        if len(columns) == 0:
            _cols = r.zrangebyscore(k, min=0, max=0)
            columns = _cols[0].decode().split(',') if _cols else columns

        # 构造结果集
        index = []
        values = []
        for i in _sub_data:
            # 反序列化，格式示例：[(b'20200101|0.12,2.3,0.5', 20200101), (b'20200102|0.05,1.45,2.55', 20200102)]
            _dt, _ser = deserializer(i[0])
            index.append(_dt)
            values.append(_ser)
        # 从缓存中反序列化的列与源数据列不匹配时，以源数据列为准
        df = pd.DataFrame(data=values, index=index).sort_index()
        c_cols = list(df.columns)
        c_cols.sort()
        r_cols = list(columns)
        r_cols.sort()
        if str(c_cols) != str(r_cols) and len(columns) > 0:
            df.columns = columns
        res_map[fetcher] = df

    # 释放redis连接
    r.close()

    return res_map


def query_raw_multi_time_series_by_score(names, min_score, max_score):
    """
    一次性查询多个时间序列缓存在指定时间区间的数据
    :param names: <list<str>> 多个缓存名称列表
    :param min_score: <int> 起始日期
    :param max_score: <int> 结束日期
    :return: <dict<name, values>> 其中values格式：
            示例：[(b'c1,c2,c3', 0), (b'20200101|0.12,2.3,0.5', 20200101), (b'20200102|0.05,1.45,2.55', 20200102)]
            第一个元素为字段名称定义
    """
    _lua_script = """
    local data = {}
    local min_score = ARGV[1]
    local max_score = ARGV[2]

    for i=1,#KEYS do
        local cols = redis.call("ZRANGEBYSCORE", KEYS[i], 0, 0, 'WITHSCORES')
        local arr = redis.call("ZRANGEBYSCORE", KEYS[i], min_score, max_score, 'WITHSCORES')
        -- 添加columns信息
        if #cols == 2 then
            table.insert(arr, 1, cols[2])
            table.insert(arr, 1, cols[1])
        end
        data[i] = arr
    end
    return data
    """
    redis = get_redis()
    keys = list(build_ts_key(name) for name in names)
    query = redis.register_script(_lua_script)
    data = query(keys=keys, args=[min_score, max_score])
    result = {}
    for i in range(len(names)):
        _data = data[i]
        _arr = []
        j = 0
        while j < len(_data):
            _arr.append((_data[j], int(_data[j + 1])))
            j = j + 2
        result[names[i]] = _arr
    redis.close()
    return result


def __list_dt_range(start_dt_int, end_dt_int):
    """
    查询指定日期区间的日期列表
    :param start_dt_int: <int> 起始日期，格式：%Y%m%d
    :param end_dt_int: <int> 截至日期，哥特式：%Y%m%d
    :return: <list<int>> 日历列表
    """
    # 按自然日处理
    start_dt = datetime.datetime.strptime(str(start_dt_int), '%Y%m%d')
    end_dt = datetime.datetime.strptime(str(end_dt_int), '%Y%m%d')
    delta = end_dt - start_dt
    # 生成自然日序列
    dts = [start_dt] + list(start_dt + datetime.timedelta(days=i + 1) for i in range(delta.days))
    dts = list(int(d.strftime('%Y%m%d')) for d in dts)
    return [] if dts is None else dts


def __calc_supply_date_range(data, days):
    """
    计算缓存数据中需要补数据的时间区间
    :param data: <list<tuple>> 缓存数据
    :param days: <int> 目标日期列表
    :return: <list<tuple>>, list<int>>: 补数据的时间区间，以及日历列表
    """
    supply_dt_range = []
    # 缓存数据中已有日期列表，格式：[20190101, 20190101, 20190103]
    exist_dts = set(i[1] for i in data)

    # 声明日期缺口起止变量
    _sup_s, _sup_e = None, None
    # 遍历交易日历/自然日历
    for d in days:
        # 如果日期在缓存中不存在
        if d not in exist_dts:
            # 则标记缺口起始日期和结束日期
            if _sup_s is None:
                _sup_s = d
            _sup_e = d
        else:
            # 头部或内部缺口：如果发现存在缺口起止日期，则收集起来，最后返回
            if _sup_s is not None:
                supply_dt_range.append((_sup_s, _sup_e))
                # 清空标记，进入下个迭代
                _sup_s, _sup_e = None, None
    # 尾部缺口
    if _sup_s is not None:
        supply_dt_range.append((_sup_s, _sup_e))

    return supply_dt_range


class TailNoneCleaner(threading.Thread):
    """
    时间序列缓存尾部None值清理
    """

    def __init__(self, cache_name, deserializer=deserialize_number_row):
        threading.Thread.__init__(self)
        self.cache_name = cache_name
        self.deserializer = deserializer

    def run(self):
        # 获取redis连接
        r = get_redis()
        k = build_ts_key(self.cache_name)

        # 倒序从尾部开始检查并清理None值所在行
        _batch = 10
        rows = r.zrevrange(k, 0, _batch)
        _stop = False
        while len(rows) > 0 and not _stop > 0:
            for row in rows:
                dt, ser = self.deserializer(row)
                ser = pd.Series(list(ser)).dropna()
                if len(ser) == 0:
                    logger.debug(f'删除缓存key={k}的row={row}')
                    r.zrem(k, row)
                else:
                    _stop = True
                    break
            # 查询下一批
            if not _stop:
                rows = r.zrevrange(k, 0, _batch)

        r.close()


def clear_cached_value(clean_days=15):
    """
    清除时间序列缓存
    :param clean_days:<int> 最近15天
    :return:
    """
    end_dt = get_today()
    start_dt = get_offset_day(end_dt, -clean_days)
    start_dt_int, end_dt_int = date_to_int(start_dt), date_to_int(end_dt)

    # 获取redis连接
    redis = get_redis()
    # 检出所有的缓存key
    keys = redis.keys(build_ts_key('*'))
    logger.info(f'开始清除时间序列最近{clean_days}天内缓存数据！')
    for k in keys:
        try:
            _k = k.decode()
            # 删除区间缓存值
            delete_time_series_cache_value(get_cache_name(_k), start_dt_int, end_dt_int)
            logger.debug(f'完成缓存数据修复清除，key={_k}')
        except Exception as ex:
            logger.error(f'缓存数据清除异常，ex={ex}', exc_info=True)
    logger.info(f'完成清除时间序列最近{clean_days}天内缓存数据！')
    # 释放连接
    redis.close()


def fix_cached_value(cache_name_pattern, build_fetcher_by_cache_name, fix_days=30,
                     serializer=serialize_number_row, deserializer=deserialize_number_row):
    """
    缓存数据修复
    :param cache_name_pattern: <str> 缓存名称匹配模式，具体见redis的keys匹配规则
    :param build_fetcher_by_cache_name: <func> 数据Fetcher构造函数，基于缓存名称构造，函数入参为缓存名称
    :param fix_days: <int> 修复数据的天数，自然日
    :param serializer: <func> 缓存数据序列化函数，与函数query_time_series_by_range保持一致
    :param deserializer: <func> 缓存数据反序列化函数，与函数query_time_series_by_range保持一致
    :return:
    """
    # 申明数据修复的时间区间：当前时间到30天以前的时间
    end_dt = get_today()
    start_dt = get_offset_day(end_dt, -fix_days)
    start_dt_int, end_dt_int = date_to_int(start_dt), date_to_int(end_dt)

    # 获取redis连接
    redis = get_redis()
    # 检出所有的缓存key
    keys = redis.keys(build_ts_key(cache_name_pattern))
    for k in keys:
        try:
            _k = k.decode()
            # 初始化取数对象
            _fetcher = build_fetcher_by_cache_name(get_cache_name(_k))
            _cache_name = _fetcher.get_cache_name()
            # 删除区间缓存值
            delete_time_series_cache_value(_cache_name, start_dt_int, end_dt_int)
            # 重新补数据
            query_time_series_by_range(_cache_name, start_dt_int, end_dt_int, fetcher=_fetcher,
                                       serializer=serializer, deserializer=deserializer)
            logger.debug(f'完成缓存数据修复，key={_k}')
        except Exception as ex:
            logger.error(f'缓存数据修复异常，ex={ex}', exc_info=True)
    # 释放连接
    redis.close()
