# -*- coding: utf-8 -*-
import os
import logging
import datetime
import time
import copy
from jspytool.cache import get_redis, create_key
from jspytool.cache.locker import acquire_lock, expire_lock
from jspytool.util.file_util import create_file_if_not_exist
from jspytool.util.wrapper import async_call
from jspytool.logger.redis_log_handler import RedisLogHandler
from logging.handlers import TimedRotatingFileHandler


__all__ = ['logger', 'configure_logger', 'write_redis_log_to_file_async', 'write_redis_log_to_file',
           'add_timed_roting_handler']

# 全局logger
default_log_format = '%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s'
logging.basicConfig(level=logging.getLevelName('INFO'), format=default_log_format)
logger = logging.getLogger()


# 从redis读日志写本地文件的日志对象
__redis_2_file_logger = None


# 日志设置
def configure_logger(_logger, log_cfg=None):
    """
    配置日志对象，决定logger写redis还是写本地文件
    :param _logger: <logging> 日志对象
    :param log_cfg: <dict> 配置详情，说明：
        {
            "level": "INFO",  # 日志级别
            "log_format": "%(message)%",  # 日志格式
            "with_pid": True,  # 日志文件是否带上进程pid作为文件后缀，单机多进程下写本地文件时建议设置为True，避免竞争文件句柄
            "debug_file": "/data/logs/app/debug.log",  # debug日志文件路径
            "info_file": "/data/logs/app/info.log",  # debug日志文件路径
            "error_file": "/data/logs/app/error.log",  # debug日志文件路径
            "is_redis_log": False,  # 是否启用写日志到Redis队列，单机多进程下推荐该方案，结合分布式调度系统使用
        }
    :return: _logger
    """
    # 提取配置项
    if log_cfg is None:
        log_cfg = {}
    level = log_cfg.get('level', 'INFO').upper()
    format_str = log_cfg.get('log_format', default_log_format)
    with_pid = log_cfg.get('with_pid', True)
    debug_file_path = log_cfg.get('debug_file')
    info_file_path = log_cfg.get('info_file', './info.log')
    error_file_path = log_cfg.get('error_file', './error.log')
    is_redis_log = log_cfg.get('is_redis_log', False)

    # 设置日志级别
    _logger.setLevel(logging.getLevelName(level))
    # 是否启用redis日志队列模式
    if is_redis_log:
        if debug_file_path:
            _logger.addHandler(RedisLogHandler(logging.DEBUG, format_str))
        _logger.addHandler(RedisLogHandler(logging.INFO, format_str))  # INFO日志处理器
        _logger.addHandler(RedisLogHandler(logging.ERROR, format_str))  # ERROR日志处理器
    else:
        _pid = str(os.getpid())  # 每个进程一个日志文件，防止多进程竞争文件句柄
        _info_file_path = info_file_path + f'.pid{_pid}' if with_pid else info_file_path
        _error_file_path = error_file_path + f'.pid{_pid}' if with_pid else error_file_path
        create_file_if_not_exist(_info_file_path)
        create_file_if_not_exist(_error_file_path)

        if debug_file_path:
            add_timed_roting_handler(_logger, logging.DEBUG, debug_file_path, format_str)  # DEBUG日志处理器
        add_timed_roting_handler(_logger, logging.INFO, _info_file_path, format_str)  # INFO日志处理器
        add_timed_roting_handler(_logger, logging.ERROR, _error_file_path, format_str)  # ERROR日志处理器

    return _logger


# 给logger添加时间滚动写日志文件handler
def add_timed_roting_handler(_logger, level, file_path, format_str):
    _handler = TimedRotatingFileHandler(file_path, when='midnight', interval=1, backupCount=30, encoding='UTF-8')
    _handler.setLevel(level)
    _handler.setFormatter(logging.Formatter(format_str))
    _logger.addHandler(_handler)


# 获取从redis读日志写本地文件的日志对象
def __get_redis_2_file_logger(log_cfg=None):
    global __redis_2_file_logger
    if __redis_2_file_logger is None:
        __redis_2_file_logger = logging.getLogger('redis_2_file_logger')
        __tmp = copy.deepcopy(log_cfg if log_cfg else {})
        __tmp.update({
            'is_redis_log': False,
            'log_format': '%(message)s',
            'with_pid': False
        })
        configure_logger(__redis_2_file_logger, __tmp)
    return __redis_2_file_logger


@async_call()
def write_redis_log_to_file_async(log_cfg=None):
    """
    异步写redis日志到本地文件
    :param log_cfg:
    :return:
    """
    write_redis_log_to_file(log_cfg)


def write_redis_log_to_file(log_cfg=None):
    """
    写redis日志到本地文件
    """
    _locker_name = 'redis_writer_scheduler'
    # 获取分布式锁，确保多进程下只有一个进程写日志到文件
    _locker_id = acquire_lock(_locker_name, acquire_timeout=3, lock_expire_seconds=30)
    if _locker_id:
        _redis = get_redis()
        _start = datetime.datetime.now()
        while True:
            try:
                # 写error日志
                _msg = _redis.lpop(create_key('log_queue', 'error'))
                if _msg is not None:
                    __get_redis_2_file_logger(log_cfg).error(_msg.decode())
                # 写debug日志
                _msg = _redis.lpop(create_key('log_queue', 'debug'))
                if _msg is not None:
                    __get_redis_2_file_logger(log_cfg).debug(_msg.decode())
                # 写info日志
                _msg = _redis.lpop(create_key('log_queue', 'info'))
                if _msg is not None:
                    __get_redis_2_file_logger(log_cfg).info(_msg.decode())
                else:
                    time.sleep(1)

                # 每隔5秒延长一次锁
                _cost = int((datetime.datetime.now() - _start).total_seconds() * 1000)
                if _cost >= 5 * 1000:
                    _start = datetime.datetime.now()
                    _hold = expire_lock(_locker_name, _locker_id, 15)
                    if not _hold:
                        # 重新获取锁
                        _locker_id = acquire_lock(_locker_name, acquire_timeout=3, lock_expire_seconds=30)
                        # 获取锁失败，则退出循环
                        if not _locker_id:
                            print('获取日志锁失败，退出循环')
                            break
            except Exception as ex:
                print(f'写日志异常，ex={ex}')
                # 重新获取连接
                try:
                    _redis.close()
                except Exception as ex1:
                    print('关闭redis连接异常')
                # 重新获取连接
                _redis = get_redis()

