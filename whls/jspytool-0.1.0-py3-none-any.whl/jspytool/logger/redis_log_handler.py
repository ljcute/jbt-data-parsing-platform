# -*- coding: utf-8 -*-
import logging
import copy
from jspytool.cache import get_redis, create_key


class RedisLogHandler(logging.Handler):
    """
    将日志写入到redis队列，队列命名：
    pypra:log:debug
    pypra:log:info
    pypra:log:warning
    pypra:log:error
    """

    def __init__(self, level_int, format_str):
        """
        Initialise an instance, using the passed queue.
        """
        logging.Handler.__init__(self)
        self.setLevel(level_int)
        self.setFormatter(logging.Formatter(format_str))

    def enqueue(self, record):
        """
        Enqueue a record.

        The base implementation uses put_nowait. You may want to override
        this method if you want to use blocking, timeouts or custom queue
        implementations.
        """
        try:
            if record.levelno >= self.level:
                _key = create_key('log_queue', logging.getLevelName(self.level).lower())
                _redis = get_redis()
                _redis.rpush(_key, record.msg)
                _redis.ltrim(_key, 0, 1024)
                _redis.close()
        except Exception as ex:
            print(f'发送log到redis失败，error={ex}')

    def prepare(self, record):
        """
        Prepares a record for queuing. The object returned by this method is
        enqueued.

        The base implementation formats the record to merge the message
        and arguments, and removes unpickleable items from the record
        in-place.

        You might want to override this method if you want to convert
        the record to a dict or JSON string, or send a modified copy
        of the record while leaving the original intact.
        """
        # The format operation gets traceback text into record.exc_text
        # (if there's exception data), and also returns the formatted
        # message. We can then use this to replace the original
        # msg + args, as these might be unpickleable. We also zap the
        # exc_info and exc_text attributes, as they are no longer
        # needed and, if not None, will typically not be pickleable.
        msg = self.format(record)
        # bpo-35726: make copy of record to avoid affecting other handlers in the chain.
        record = copy.copy(record)
        record.message = msg
        record.msg = msg
        record.args = None
        record.exc_info = None
        record.exc_text = None
        return record

    def emit(self, record):
        """
        Emit a record.

        Writes the LogRecord to the queue, preparing it for pickling first.
        """
        try:
            self.enqueue(self.prepare(record))
        except Exception as ex:
            self.handleError(record)

