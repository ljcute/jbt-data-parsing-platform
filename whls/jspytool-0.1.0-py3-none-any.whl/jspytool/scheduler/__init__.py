# -*- coding: utf-8 -*-
import importlib
import threading
import time
import logging
from jspytool import logger
from jspytool.cache.locker import acquire_lock, expire_lock
from jspytool.cache import get_redis, create_key
from apscheduler.schedulers.background import BackgroundScheduler as Scheduler
from pytz import timezone

__all__ = ['Master', 'Worker', 'LocalScheduler']
# 时区定义
tz = timezone('Asia/Shanghai')
# 设置apscheduler日志级别
logging.getLogger('apscheduler.executors.default').setLevel(logging.WARNING)


class Master(threading.Thread):
    """
    调度线程，调度线程只负责任务调度，通过apscheduler来触发cron事件，
    将任务信息推送到redis队列中，交由作业线程去执行
    """
    def __init__(self, dist_jobs=(), dist_locker_name='dist_scheduler', dist_job_queue_name='job_queue:simple'):
        threading.Thread.__init__(self)
        self.alive = True
        self.dist_job_dict = {job['id']: job for job in dist_jobs}
        self.dist_locker_name = dist_locker_name
        self.dist_job_queue_name = dist_job_queue_name

    def send_dist_job(self, job_id):
        """
        发送job_id到redis队列，通知作业线程执行对应job
        """
        _job = self.dist_job_dict.get(job_id)
        if _job is None:
            logger.error(f'不存在的job[job_id={job_id}]')
        else:
            try:
                _redis = get_redis()
                _key = create_key(self.dist_job_queue_name)
                _redis.lpush(_key, job_id)
                _redis.close()

                if _job.get('trigger', 'cron') != 'interval':
                    logger.info(f'触发job[job_id={job_id}]')
            except Exception as ex:
                logger.error(f'发送job到redis失败，error={ex}', exc_info=True)

    def run(self) -> None:
        while self.alive:
            _scheduler = None
            try:
                # 获取锁，确保多进程下只有一个进程调度任务，其他进程执行任务
                _locker_id = acquire_lock(self.dist_locker_name, acquire_timeout=3, lock_expire_seconds=60)
                if not _locker_id:
                    # 休眠1分钟后，重新尝试选举为调度线程
                    time.sleep(60)
                    continue
                # 获得分布式锁，选举当前线程为调度线程
                _scheduler = Scheduler(timezone=tz)
                # 注册任务
                for _job_id, job in self.dist_job_dict.items():
                    _trigger = job.get('trigger', 'cron')
                    _scheduler.add_job(self.send_dist_job, _trigger, args=[_job_id], kwargs=None, id=_job_id,
                                       **job['trigger_kwargs'])
                # 启动定时任务
                _scheduler.start()
                logger.info('分布式定时任务调度线程已启动')
                # 常驻线程，保活锁的存活时间
                count = 0
                while self.alive:
                    # 每隔3秒保持一次锁失效时间（10秒）
                    if expire_lock(self.dist_locker_name, _locker_id, 10):
                        # 每隔10分钟打印一次日志，以方便查看定时任务线程是否存活
                        count += 1
                        if count == 200:
                            count = 0
                            logger.info('Distributed scheduler is running...')
                        # 休眠3秒
                        time.sleep(3)
                    else:
                        # 获取锁失败，关闭当前调度器
                        logger.info('分布式定时调度线程获取锁失败，关闭当前调度，重新开始选举调度线程')
                        _scheduler.shutdown(wait=False)
                        break
            except Exception as ex:
                try:
                    if _scheduler is not None:
                        _scheduler.shutdown(wait=False)
                except Exception as ex1:
                    logger.info(f'关闭调度器异常，ex={ex1}', exc_info=True)
                logger.error(f'调度线程执行异常，ex={ex}', exc_info=True)

    def stop(self):
        self.alive = False


class Worker(threading.Thread):
    """
    作业线程，负责具体的任务执行，从redis队列中即时拉取任务执行
    """
    def __init__(self, dist_jobs=(), dist_job_queue_name='job_queue:simple'):
        threading.Thread.__init__(self)
        self.alive = True
        self.dist_job_dict = {job['id']: job for job in dist_jobs}
        self.dist_job_queue_name = dist_job_queue_name

    def run(self) -> None:
        logger.info('启动分布式作业线程')
        while self.alive:
            try:
                _redis = get_redis()
                _key = create_key(self.dist_job_queue_name)
                _job_id = _redis.rpop(_key)
                _redis.close()
                if _job_id is not None:
                    _job_id = _job_id.decode('utf8')
                    job = self.dist_job_dict[_job_id]
                    _is_log = job.get('trigger', 'cron') != 'interval'  # interval任务不记录日志
                    if _is_log:
                        logger.info(f'开始执行job[job_id={_job_id}]...')
                    if callable(job['func']):
                        func = job['func']
                    else:
                        # 动态引入模块
                        mod = importlib.import_module(job['module'])
                        # 动态引入函数
                        func = eval('mod.' + job['func'])
                    # 执行任务
                    args = job.get('func_args', None)
                    kwargs = job.get('func_kwargs', None)
                    if args and kwargs:
                        func(*args, **kwargs)
                    elif args and not kwargs:
                        func(*args)
                    elif kwargs and not args:
                        func(**kwargs)
                    else:
                        func()
                    if _is_log:
                        logger.info(f'完成执行job[job_id={_job_id}]')
                else:
                    # 休眠10秒
                    time.sleep(10)
            except Exception as ex:
                logger.error(f'执行job异常，error={ex}', exc_info=True)

    def stop(self):
        self.alive = False


class LocalScheduler(threading.Thread):
    """本地调度器"""
    def __init__(self, local_jobs=()):
        threading.Thread.__init__(self)
        self.alive = True
        # 初始化调度器
        self.scheduler = Scheduler(timezone=tz)
        self.local_jobs = local_jobs

    def run(self) -> None:
        # 注册任务
        for job in self.local_jobs:
            _job_id = job.get('id', None)
            _trigger = job.get('trigger', 'cron')
            if callable(job['func']):
                func = job['func']
            else:
                # 动态引入模块
                mod = importlib.import_module(job['module'])
                # 动态引入函数
                func = eval('mod.' + job['func'])
            args = job.get('func_args', [])
            kwargs = job.get('func_kwargs', None)
            # 注册定时任务
            self.scheduler.add_job(func, _trigger, args=args, kwargs=kwargs, id=_job_id, **job['trigger_kwargs'])
        # 启动定时任务
        self.scheduler.start()
        logger.info('并发定时任务调度线程已启动')
        # 常驻线程
        count = 0
        while self.alive:
            # 每隔10分钟打印一次日志，以方便查看定时任务线程是否存活
            count += 1
            if count == 200:
                count = 0
                logger.info('Concurrent scheduler is running...')
            # 休眠3秒
            time.sleep(3)

    def stop(self):
        self.alive = False


"""
定时任务注册表
参数说明：
id (str) - 定时任务ID
module (str) - 定时任务代码模块名称
func (str|function) - 定时任务入口函数名称
func_args (tuple) - 定时任务函数args参数
func_kwargs (dict) - 定时任务函数kwargs参数
trigger - 定时任务类型，cron：表达式执行（缺省），interval：间隔执行
trigger_kwargs (dict) - trigger_kwargs参数，具体定义如下：
    year (int|str) – 年，4位数字
    month (int|str) – 月 (范围1-12)
    day (int|str) – 日 (范围1-31)
    week (int|str) – 周 (范围1-53)
    day_of_week (int|str) – 周内第几天或者星期几 (范围0-6 或者 mon,tue,wed,thu,fri,sat,sun)
    hour (int|str) – 时 (范围0-23)
    minute (int|str) – 分 (范围0-59)
    second (int|str) – 秒 (范围0-59)
    start_date (datetime|str) – 最早开始日期(包含)
    end_date (datetime|str) – 最晚结束时间(包含)
    timezone (datetime.tzinfo|str) – 指定时区
    seconds (int|str) - 间隔多少秒执行，适应于trigger = 'interval' 类型任务
示例：
{
    'id': 'my id',
    'func': print,
    'func_args': ('hello', '肖波'),
    'trigger': 'interval',
    'trigger_kwargs': {'seconds': 5}
}
{
    'id': 'my id',
    'module': 'pypdp.pdp.research.profile.model.test_job',
    'func': 'job_no_arg',
    'trigger_kwargs': {'minute': '*/1', 'second': 1}
},
{
    'id': 'my id',
    'module': 'pypdp.pdp.research.profile.model.test_job',
    'func': 'job_with_args',
    'func_args': (1, 2),
    'trigger_kwargs': {'minute': '*/1', 'second': 2}
},
{
    'id': 'my id',
    'module': 'pypdp.pdp.research.profile.model.test_job',
    'func': 'job_with_kwargs',
    'func_kwargs': {'arg1': 'hey', 'arg2': 'guys'},
    'trigger_kwargs': {'minute': '*/1', 'second': 3}
},
{
    'id': 'my id',
    'module': 'pypdp.pdp.research.profile.model.test_job',
    'func': 'job_with_args_kwargs',
    'func_args': (3, 4),
    'func_kwargs': {'arg3': 'great', 'arg4': 'job'},
    'trigger_kwargs': {'minute': '*/1', 'second': 4}
}
"""