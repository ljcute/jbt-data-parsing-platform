# -*- coding: utf-8 -*-
import pandas as pd
from dbutils.pooled_db import PooledDB
from jspytool import logger

__all__ = ['init_data_sources', 'get_ds', 'SQLHelper', 'get_ds_extra']
# 数据源缓存
ds_cfg_list = []
ds_map = {}
ds_ext = {}


def init_data_sources(ds_cfg_arr):
    """
    初始化数据源配置
    :param ds_cfg_arr: <list<dict> 数据源配置列表，格式举例：
        MySQL配置：见单元测试代码
        Oracle配置：见单元测试代码
        SQLServer配置：见单元测试代码
    :return:
    """
    global ds_cfg_list
    ds_cfg_list = ds_cfg_arr


def get_ds(ds_name):
    """
    获取指定数据源
    :param ds_name:<str> 数据源名称
    :return: 数据库连接池PooledDB对象
    """
    _ds = ds_map.get(ds_name, None)
    # 直接返回已注册的数据源
    if _ds is not None:
        return _ds
    # 创建对应数据源，并注册到ds_map
    for _ds_cfg in ds_cfg_list:
        if _ds_cfg['name'] == ds_name:
            _cfg = _ds_cfg['config']
            _ds = PooledDB(
                creator=__parse_creator(_ds_cfg['dialect']),
                maxconnections=_ds_cfg.get('maxconnections', 15),
                mincached=_ds_cfg.get('mincached', 1),
                maxcached=_ds_cfg.get('maxcached', 1),
                maxshared=_ds_cfg.get('maxshared', 0),
                blocking=_ds_cfg.get('blocking', True),
                maxusage=_ds_cfg.get('maxusage', None),
                setsession=_ds_cfg.get('setsession', []),
                ping=_ds_cfg.get('ping', 1),
                **_cfg
            )
            # 注册
            ds_map[_ds_cfg['name']] = _ds
            return _ds
    raise Exception('非法的数据源，ds_name:' + ds_name)


def get_ds_extra(ds_name):
    """
    获取数据源的扩展配置
    :param ds_name: <str> 数据源名称
    :return: <dict> 扩展配置
    """
    _ext = ds_ext.get(ds_name, None)
    # 直接返回已注册的数据源扩展配置
    if _ext is not None:
        return _ext
    # 找到对应数据源extra配置，并注册到ds_ext
    for _ds_cfg in ds_cfg_list:
        if _ds_cfg['name'] == ds_name:
            _ext = _ds_cfg.get('extra', {})
            # 注册
            ds_ext[_ds_cfg['name']] = _ext
            return _ext
    raise Exception('非法的数据源，ds_name:' + ds_name)


def __parse_creator(dialect):
    if dialect == 'mysql':
        # import pymysql
        # return pymysql
        import mysql.connector as dbapi2
        return dbapi2
    elif dialect == 'mssql':
        import pymssql
        return pymssql
    elif dialect == 'oracle':
        import cx_Oracle
        return cx_Oracle
    else:
        raise Exception('不支持的数据库类型，dialect:' + dialect)


class SQLHelper(object):

    @staticmethod
    def open(pool):
        _conn = pool.connection()
        _cursor = _conn.cursor()
        return _conn, _cursor

    @staticmethod
    def close(conn, cursor):
        cursor.close()
        conn.close()

    @classmethod
    def fetch_one(cls, ds_name, sql, args=()):
        logger.debug(f'query sql:\n{sql}\nquery sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        cursor.execute(sql, args)
        obj = cursor.fetchone()
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_one_as_dict(cls, ds_name, sql, args=()):
        logger.debug(f'query sql:\n{sql}\nquery sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        cursor.execute(sql, args)
        row = cursor.fetchone()
        obj = None
        if row:
            desc = cursor.description
            obj = dict(zip([str(col[0]).lower() for col in desc], row))
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_all(cls, ds_name, sql, args=()):
        logger.debug(f'query sql:\n{sql}\nquery sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        cursor.execute(sql, args)
        obj = cursor.fetchall()
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_all_as_dict(cls, ds_name, sql, args=(), lower_case_column=True):
        logger.debug(f'query sql:\n{sql}\nquery sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        cursor.execute(sql, args)
        desc = cursor.description
        obj = [
            dict(zip([str(col[0]).lower() if lower_case_column else col[0] for col in desc], row))
            for row in cursor.fetchall()
        ]
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_all_as_df(cls, ds_name, sql, args=(), lower_case_column=True):
        """
        查询结果集为DataFrame对象返回，列名对应字段名称，全部小写
        :param lower_case_column: 列名是否需要小写，默认需要
        :param ds_name:
        :param sql:
        :param args:
        :return:
        """
        logger.debug(f'query sql:\n{sql}\nquery sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        cursor.execute(sql, args)
        data = cursor.fetchall()
        columns = list(i[0].lower() if lower_case_column else i[0] for i in cursor.description)
        cls.close(conn, cursor)
        return pd.DataFrame(data=data, columns=columns)

    @classmethod
    def insert(cls, ds_name, sql, args=()):
        logger.debug(f'insert sql:\n{sql}\ninsert sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        try:
            cursor.execute(sql, args)
            conn.commit()
        except Exception as ex:
            logger.error(f'insert异常，sql：\n{sql}\nargs:\n{args}', exc_info=True)
            conn.rollback()
            raise ex
        finally:
            cls.close(conn, cursor)

    @classmethod
    def batch_insert(cls, ds_name, sql, args=()):
        logger.debug(f'batch insert sql:\n{sql}\ninsert sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        try:
            cursor.executemany(sql, args)
            conn.commit()
        except Exception as ex:
            logger.error(f'batch insert异常，sql：\n{sql}\nargs:\n{args}', exc_info=True)
            conn.rollback()
            raise ex
        finally:
            cls.close(conn, cursor)

    @classmethod
    def batch_update(cls, ds_name, sql, args=()):
        logger.debug(f'batch update sql:\n{sql}\n update sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        try:
            cursor.executemany(sql, args)
            conn.commit()
        except Exception as ex:
            logger.error(f'batch update异常，sql：\n{sql}\nargs:\n{args}', exc_info=True)
            conn.rollback()
            raise ex
        finally:
            cls.close(conn, cursor)

    @classmethod
    def delete(cls, ds_name, sql, args=()):
        logger.debug(f'delete sql:\n{sql}')
        logger.debug(f'delete sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        try:
            cursor.execute(sql, args)
            conn.commit()
        except Exception as ex:
            logger.error(f'delete异常，sql：\n{sql}\nargs:\n{args}', exc_info=True)
            conn.rollback()
            raise ex
        finally:
            cls.close(conn, cursor)

    @classmethod
    def update(cls, ds_name, sql, args=()):
        logger.debug(f'update sql:\n{sql}\nupdate sql args:\n{args}')
        conn, cursor = cls.open(get_ds(ds_name))
        try:
            cursor.execute(sql, args)
            conn.commit()
        except Exception as ex:
            logger.error(f'update异常，sql：\n{sql}\nargs:\n{args}', exc_info=True)
            conn.rollback()
            raise ex
        finally:
            cls.close(conn, cursor)
