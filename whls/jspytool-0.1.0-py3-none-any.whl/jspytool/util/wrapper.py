# -*- coding: utf-8 -*-
import time
import threading
from jspytool import logger
from functools import wraps
from jspytool.util.func_util import make_func_invoke_key, flat_func_param
from jspytool.util.concurrent_util import RetFuncExecThread


# 响应结果标准化包装
def response_wrap(log=False):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kw):
            from flask import jsonify
            res = func(*args, **kw)
            try:
                invoke_id = threading.current_thread().__getattribute__("invoke_id")
                threading.current_thread().__delattr__("invoke_id")
            except Exception as e:
                invoke_id = None
            if log:
                res_str = str(res)
                if len(res_str) < 500:
                    logger.info('响应web api网关，resp=%s', {'code': '0', 'msg': 'success', 'invoke_id': invoke_id, 'data': res})
                else:
                    logger.info('响应web api网关:  %s', {'code': '0', 'msg': 'success', 'invoke_id': invoke_id, 'data': res_str[:500]+"...省略..."})
            return jsonify({'code': '0', 'msg': 'success', 'data': res})
        return wrapper

    return decorator


# 重试装饰器
def retry(attempt=3, delay_seconds=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kw):
            att = 0
            ex = None
            while att <= attempt:
                try:
                    return func(*args, **kw)
                except Exception as e:
                    time.sleep(delay_seconds)
                    att += 1
                    ex = e
            raise ex

        return wrapper

    return decorator


# 打印耗时装饰器
def log_cost_mills(great_than=1000, msg=''):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kw):
            import datetime
            _start = datetime.datetime.now()
            _res = func(*args, **kw)
            _end = datetime.datetime.now()
            _cost = int((_end - _start).total_seconds()*1000)
            if _cost >= great_than:
                _args = flat_func_param(func, args, kw, fmt_dt=True)
                _args_txt = '{}'.format(_args)
                _args_txt = _args_txt if len(_args_txt) <= 100 else f'{_args_txt[:100]}...'
                logger.info('%s%s %s 执行耗时：%s mills' % (str(func.__name__), _args_txt, msg, _cost))
            return _res

        return wrapper

    return decorator


# 缓存装饰器
def cacheable(key=None, ex=None, px=None, nx=False, xx=False, keepttl=False, typed=False):
    marker = ('marker',)

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kw):
            import pickle
            from pandas import DataFrame, Series
            from jspytool.cache import get_redis, create_key

            if key is not None:
                _args = flat_func_param(func, args, kw, fmt_dt=True)
                _key = create_key(key.format(*_args))
            else:
                # 生成key前缀
                prefix = create_key("func:{}.{}:".format(func.__module__, func.__name__))
                # 根据入参生成完整的key
                _key = make_func_invoke_key(func, args, kw, marker, typed, prefix)
            _r = None
            try:
                # 获取redis客户端连接
                _r = get_redis()
                # 判断缓存中是否存在，若存在则直接返回缓存数据
                _res = _r.get(_key)
                if _res is not None:
                    _r.close()
                    logger.debug(f'取缓存数据，key={_key}')
                    return pickle.loads(_res)
            except Exception as ex1:
                logger.error(f'缓存数据获取失败，error={ex1}', exc_info=True)

            # 执行源函数
            _res = func(*args, **kw)

            try:
                if _res is None \
                        or (isinstance(_res, dict) and len(_res) == 0) \
                        or (isinstance(_res, list) and len(_res) == 0) \
                        or (isinstance(_res, tuple) and len(_res) == 0) \
                        or (isinstance(_res, set) and len(_res) == 0) \
                        or (isinstance(_res, Series) and len(_res) == 0) \
                        or (isinstance(_res, DataFrame) and len(_res.index) == 0):
                    if _r:
                        _r.close()
                    return _res
                # 缓存结果到redis
                if _r:
                    _r.set(_key, pickle.dumps(_res), ex=ex, px=px, nx=nx, xx=xx, keepttl=keepttl)
                    _r.close()
            except Exception as ex2:
                logger.error(f'缓存数据写入失败，error={ex2}', exc_info=True)

            return _res

        return wrapper

    return decorator


# 函数异步化调用
def async_call(ret=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kw):
            t = RetFuncExecThread(func=func, params=args, kw=kw)
            t.start()
            return ret
        return wrapper
    return decorator

