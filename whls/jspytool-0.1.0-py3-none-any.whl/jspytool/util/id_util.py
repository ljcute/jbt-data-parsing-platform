# -*- coding: utf-8 -*-
import datetime
import time
import random
import threading
import os
import socket
from jspytool import logger
from jspytool.util.wrapper import log_cost_mills, retry
from jspytool.cache.locker import acquire_lock, release_lock

# 64位ID的划分
WORKER_ID_BITS = 5
DATACENTER_ID_BITS = 5
SEQUENCE_BITS = 12

# 最大取值计算
MAX_WORKER_ID = -1 ^ (-1 << WORKER_ID_BITS)  # 2**5-1 0b11111
MAX_DATACENTER_ID = -1 ^ (-1 << DATACENTER_ID_BITS)

# 移位偏移计算
WOKER_ID_SHIFT = SEQUENCE_BITS
DATACENTER_ID_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS
TIMESTAMP_LEFT_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS + DATACENTER_ID_BITS

# 序号循环掩码
SEQUENCE_MASK = -1 ^ (-1 << SEQUENCE_BITS)

# Twitter元年时间戳
TWEPOCH = 1288834974657


class IdWorker(object):
    """
    用于生成IDs
    """

    def __init__(self, datacenter_id, worker_id, sequence=0):
        """
        初始化
        :param datacenter_id: <int> 数据中心（机器区域）ID
        :param worker_id: <int> 机器ID
        :param sequence: 起始序号
        """
        # sanity check
        if worker_id > MAX_WORKER_ID or worker_id < 0:
            raise ValueError('worker_id值越界')

        if datacenter_id > MAX_DATACENTER_ID or datacenter_id < 0:
            raise ValueError('datacenter_id值越界')

        self.worker_id = worker_id
        self.datacenter_id = datacenter_id
        self.sequence = sequence
        # 并发锁
        self.locker = threading.Lock()

        self.last_timestamp = -1  # 上次计算的时间戳

    @staticmethod
    def __gen_timestamp():
        """
        生成整数时间戳
        :return:int timestamp
        """
        return int(time.time() * 1000)

    def get_id(self):
        """
        获取新ID
        :return:
        """
        try:
            # 加锁
            self.locker.acquire()

            timestamp = self.__gen_timestamp()
            # 时钟回拨
            if timestamp < self.last_timestamp:
                raise Exception(f'clock is moving backwards. Rejecting requests until {self.last_timestamp}')

            if timestamp == self.last_timestamp:
                self.sequence = (self.sequence + 1) & SEQUENCE_MASK
                if self.sequence == 0:
                    timestamp = self._til_next_millis(self.last_timestamp)
            else:
                self.sequence = 0

            self.last_timestamp = timestamp

            new_id = ((timestamp - TWEPOCH) << TIMESTAMP_LEFT_SHIFT) | (self.datacenter_id << DATACENTER_ID_SHIFT) | \
                     (self.worker_id << WOKER_ID_SHIFT) | self.sequence
            # 释放锁
            self.locker.release()

            return new_id
        except Exception as ex:
            self.locker.release()  # 异常释放锁
            raise ex

    def gen_ids(self, size=1):
        """
        批量生成ID
        """
        return [self.get_id() for i in range(size)]

    def _til_next_millis(self, last_timestamp):
        """
        等到下一毫秒
        """
        timestamp = self.__gen_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self.__gen_timestamp()
        return timestamp


def get_host_ip():
    s, ip = None, '127.0.0.1'
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        try:
            s.close()
        except Exception as ex:
            logger.error(f'获取本机IP异常，ex={ex}', exc_info=True)

    return ip


__datacenter_id = int(get_host_ip().replace('.', '')) % MAX_DATACENTER_ID
__worker_id = os.getpid() % MAX_WORKER_ID
__worker = IdWorker(__datacenter_id, __worker_id, 0)


@log_cost_mills(great_than=100, msg='雪花ID生成')
@retry(attempt=5, delay_seconds=10)
def gen_ids(size=1, sync=True):
    """
    生成雪花ID
    :param size:<int> 生成ID个数
    :param sync:<bool> 是否同步，缺省True，集群或并发场景下，需借助分布式锁来避免生成重复ID
    :return :<list<long>> 雪花ID
    """
    if sync:
        _locker_name = f'{__datacenter_id}.{__worker_id}'
        _locker_id = acquire_lock(_locker_name, acquire_timeout=5, lock_expire_seconds=30)
        if _locker_id:
            ids = __worker.gen_ids(size)
            release_lock(_locker_name, _locker_id)
            return ids
        else:
            raise Exception('生成雪花ID获取分布式锁失败')
    else:
        return __worker.gen_ids(size)


def get_invoke_id():
    """
    :return:获取调用ID
    """
    dt = datetime.datetime.today().strftime('%Y%m%d')
    invoke_id = dt + 'invokeId' + str(random.randint(10000, 1000000))
    return invoke_id


if __name__ == '__main__':
    print(get_invoke_id())

