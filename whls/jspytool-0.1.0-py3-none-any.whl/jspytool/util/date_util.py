# -*- coding: utf-8 -*-
import datetime
import calendar
from dateutil.relativedelta import relativedelta


def get_today():
    """
    获取当天日期，包含当前时分秒
    """
    return datetime.datetime.today()


def get_today_date():
    """
    获取当天日期，不包含时分秒
    """
    return datetime.date.today()


def get_yesterday():
    """
    取得昨天日期
    :return:
    """
    return datetime.date.today() - datetime.timedelta(days=1)


def get_offset_x_day(offset_days=0):
    """
    取得前或后X天日期
    :return:
    """
    return datetime.date.today() - datetime.timedelta(days=offset_days)


def get_yesterday_dt():
    """
    取得昨天日期
    :return:
    """
    yesterday = get_yesterday()
    return datetime.datetime(yesterday.year, yesterday.month, yesterday.day)


def parse_dt(dt_str):
    """
    字符串转datetime
    :param dt_str <str>
    :return: datetime.datetime
    """
    return datetime.datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')


def parse_d(d_str):
    """
    字符串转datetime
    :param d_str: <str>
    :return: datetime.datetime
    """
    return int_to_date(date_to_int(d_str))


def parse_d_by(d_str, pattern):
    """
    字符串转datetime
    :param d_str:  <str>
    :param pattern: <str>
    :return: <datetime>
    """
    return datetime.datetime.strptime(d_str, pattern)


def fmt_dts(dts, fmt):
    """
    批量格式化日期
    :param dts: <list<datetime|date>> 日期对象列表
    :param fmt: 格式，例如：%Y-%m-%d
    :return: 格式化后的日期字符串列表
    """
    if dts is None:
        return dts
    fmted_dts = []
    for dt in dts:
        fmted_dts.append(None if dt is None else dt.strftime(fmt))
    return fmted_dts


def fmt_d(dt):
    """
    :param dt: <datetime|date> 日期
    :return : <str> 格式化：%Y-%m-%d
    """
    return None if dt is None else dt.strftime('%Y-%m-%d')


def fmt_dt(dt):
    """
    :param dt: <date|datetime> 日期
    :return : <str> 格式化：%Y-%m-%d %H:%M:%S
    """
    return None if dt is None else dt.strftime('%Y-%m-%d %H:%M:%S')


def get_offset_year(dt, offset):
    """
    取offset年的时间
    :param dt:
    :param offset:
    :return:
    """
    return dt + relativedelta(years=offset)


def get_offset_year_str(dt, offset):
    return get_offset_year(parse_d(dt), offset).strftime('%Y-%m-%d')


def get_offset_month(dt, offset):
    """
    取offset月的时间
    :param dt:
    :param offset:
    :return:
    """
    return dt + relativedelta(months=offset)


def get_offset_day(dt, offset):
    """
    取offset天的时间
    :param dt:
    :param offset:
    :return:
    """
    return dt + relativedelta(days=offset)


def get_last_month_end(dt):
    """
    查询指定日期上一个月末日期
    :param dt: <str|datetime> str格式 yyyy-MM-dd
    :return: <datetime>
    """
    _dt = int_to_date(date_to_int(dt))
    _pdt = get_offset_month(_dt, -1)
    _days = calendar.monthrange(_pdt.year, _pdt.month)[1]
    return datetime.datetime(_pdt.year, _pdt.month, _days)


def get_month_end(start_dt, end_dt):
    """
    查询时间段内月末的时间list
    :param start_dt: <str|datetime> str格式 yyyy-MM-dd
    :param end_dt: <str|datetime> str格式 yyyy-MM-dd
    :return: <list> datetime
    """
    _s_int_str = str(date_to_int(start_dt))
    _e_int_str = str(date_to_int(end_dt))
    _dts = []

    idx = int_to_date(_s_int_str[:6]+"01")
    end = int_to_date(_e_int_str)
    while idx <= end:
        _days = calendar.monthrange(idx.year, idx.month)[1]
        _date = datetime.datetime(idx.year, idx.month, _days)
        if _date <= end:
            _dts.append(_date)
        idx = get_offset_month(idx, 1)

    return _dts


def get_month_end_by_month(month):
    """
    查询指定月份的月底日期
    :param month: <str> 月份，格式：%Y%m，例如：'202012'
    :return: <datetime>
    """
    _year, _month = int(month[:4]), int(month[4:6])
    _days = calendar.monthrange(_year, _month)[1]
    _date = datetime.datetime(_year, _month, _days)
    return _date


def get_month_end_by_dt(dt):
    """
    查询指定日期的月末日期
    :param dt: <datetime> 日期
    :return: <datetime>
    """
    _year, _month = dt.year, dt.month
    _days = calendar.monthrange(_year, _month)[1]
    _date = datetime.datetime(_year, _month, _days)
    return _date


def get_week_friday_by_range(start_dt, end_dt):
    """
    查询时间段内的每周周五的时间list
    :param start_dt:
    :param end_dt:
    :return:
    """
    start_dt = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end_dt = parse_d(end_dt) if isinstance(end_dt, str) else end_dt

    dts = []
    _friday = get_week_friday(start_dt)
    # 如果周五在开始时间之前，则往下取一周，确保在时间区间内
    if _friday < start_dt:
        _friday = get_offset_day(_friday, 7)
    while _friday <= end_dt:
        dts.append(_friday)
        _friday = get_offset_day(_friday, 7)
    return dts


def get_quarter_end(start_dt, end_dt):
    """
    查询时间段内季度末的时间list
    :param start_dt: <str|datetime> str格式 yyyy-MM-dd
    :param end_dt: <str|datetime> str格式 yyyy-MM-dd
    :return: <list> datetime
    """
    start_dt = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end_dt = parse_d(end_dt) if isinstance(end_dt, str) else end_dt
    # 只取季末时间
    _dt = ['0331', '0630', '0930', '1231']

    dts = []
    for i in range((end_dt - start_dt).days + 1):
        _cur_date = get_offset_day(start_dt, i)
        _str_day = _cur_date.strftime('%m%d')
        if _str_day in _dt:
            dts.append(_cur_date)
    return dts


def get_rpt_day_list(start_dt, end_dt):
    """时间区间季度报告期列表 datetime类型"""
    # 0331 0630 0930 1231
    start = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end = parse_d(end_dt) if isinstance(end_dt, str) else end_dt

    date_list = []
    while start <= end:
        trd_date = start.strftime("%Y-%m-%d")
        if not (trd_date[5:10] == '03-31' or trd_date[5:10] == '06-30'
                or trd_date[5:10] == '09-30' or trd_date[5:10] == '12-31'):
            start = start + relativedelta(days=1)
        else:
            date_list.append(start)
            start = start + relativedelta(days=85)
    return date_list


def get_half_year_end(start_dt, end_dt):
    """
    查询时间段内半年最后一天的时间list
    :param start_dt:
    :param end_dt:
    :return:
    """
    start_dt = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end_dt = parse_d(end_dt) if isinstance(end_dt, str) else end_dt
    # 只取半年末时间
    _dt = ['0630', '1231']

    dts = []
    for i in range((end_dt - start_dt).days + 1):
        _cur_date = get_offset_day(start_dt, i)
        _str_day = _cur_date.strftime('%m%d')
        if _str_day in _dt:
            dts.append(_cur_date)
    return dts


def get_year_end(start_dt, end_dt):
    """
    查询时间段内每年最后一天的时间list
    :param start_dt:
    :param end_dt:
    :return:
    """
    start_dt = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end_dt = parse_d(end_dt) if isinstance(end_dt, str) else end_dt
    # 只取每年末时间
    _dt = ['1231']

    dts = []
    for i in range((end_dt - start_dt).days + 1):
        _cur_date = get_offset_day(start_dt, i)
        _str_day = _cur_date.strftime('%m%d')
        if _str_day in _dt:
            dts.append(_cur_date)
    return dts


def is_quarter_end(dt):
    """
    判断当前时间是否处于季末
    :param dt: <str|datetime>
    :return:
    """
    dt = parse_d(dt) if isinstance(dt, str) else dt
    _days = ['0331', '0630', '0930', '1231']
    _str_day = dt.strftime('%m%d')
    if _str_day in _days:
        return True
    return False


def pre_quarter_end(dt):
    """
    取指定日期上个季末日期（自然日）
    :param dt: <str|datetime>
    :return:
    """
    dt = parse_d(dt) if isinstance(dt, str) else dt
    mon = dt.month
    if 1 <= mon <= 3:
        edt = datetime.datetime(dt.year - 1, 12, 31)
    elif 4 <= mon <= 6:
        edt = datetime.datetime(dt.year, 3, 31)
    elif 7 <= mon <= 9:
        edt = datetime.datetime(dt.year, 6, 30)
    elif 10 <= mon <= 12:
        edt = datetime.datetime(dt.year, 9, 30)
    return edt


def get_week_monday(dt):
    """
    给定一个日期-返回日期所在周的周一
    :param <datetime>
    :return: 给定一个日期-返回日期所在周的周一0点时间
    """
    dt = parse_d(dt) if isinstance(dt, str) else dt
    week_start_time = dt - datetime.timedelta(days=dt.weekday(), hours=dt.hour,
                                              minutes=dt.minute, seconds=dt.second, microseconds=dt.microsecond)
    return week_start_time


def get_week_friday(dt):
    """
    给定一个日期，返回日期所在周的周五
    :param dt:
    :return:
    """
    dt = parse_d(dt) if isinstance(dt, str) else dt
    _monday = get_week_monday(dt)
    return get_offset_day(_monday, 4)


def date_to_int(dt):
    """
    日期类型转日期的整型数字表示，例如：'20201114' -> 20201114，datetime(2020, 11, 14) -> 20201114
    :param <str|datetime>
    :return <int> 日期的整型数字
    """
    if isinstance(dt, str):
        return int(dt.replace('-', '').replace('/', ''))
    elif isinstance(dt, int):
        return dt
    return int(dt.strftime('%Y%m%d'))


def int_to_date(dt_int):
    """
    整型日期转换为datetime
    :param <int|str> 整型日期
    :return <datetime>
    """
    return datetime.datetime.strptime(str(dt_int), '%Y%m%d')


def ts_int_to_date(dt_int):
    """
    [天软整型]转换为日期datetime
    :param <int|str> 整型日期
    :return <datetime>
    """
    dt = parse_d('1899-12-30')
    return dt + datetime.timedelta(days=dt_int)


def year_start_dt(dt):
    """
    获取指定日期的年初日期
    :param dt: <datetime>
    :return: <datetime>
    """
    return datetime.datetime(dt.year, 1, 1)


def month_start_dt(dt):
    """
    获取指定日期的月初日期
    :param dt: <datetime>
    :return: <datetime>
    """
    return datetime.datetime(dt.year, dt.month, 1)


def get_date_by_interval(start_dt, end_dt, interval, include=True):
    """
    按区间返回对应日期list
    :param start_dt:
    :param end_dt:
    :param interval: 取值范围：D,W,M,Q,H,Y  分别表示日、周、月、季度、半年、年
    :param include: 返回的结果中是否包含传入的开始、结束时间，默认为True
    :return:
    """
    start_dt = parse_d(start_dt) if isinstance(start_dt, str) else start_dt
    end_dt = parse_d(end_dt) if isinstance(end_dt, str) else end_dt

    dts = []
    if interval == 'D':
        for i in range((end_dt - start_dt).days + 1):
            _cur_date = get_offset_day(start_dt, i)
            dts.append(_cur_date)
    elif interval == 'W':
        dts = get_week_friday_by_range(start_dt, end_dt)
    elif interval == 'M':
        dts = get_month_end(start_dt, end_dt)
    elif interval == 'Q':
        dts = get_quarter_end(start_dt, end_dt)
    elif interval == 'H':
        dts = get_half_year_end(start_dt, end_dt)
    elif interval == 'Y':
        dts = get_year_end(start_dt, end_dt)

    # 将区间内的开始和结束时间添加进结果中
    if include and len(dts) > 0:
        _first_day = dts[0]
        _last_day = dts[-1]
        if start_dt != _first_day:
            dts.insert(0, start_dt)
        if end_dt != _last_day:
            dts.append(end_dt)
    return dts


def split_to_month_range(start_dt, end_dt, include=True):
    """
    将指定时间区间切分为月度时间起止时间集合
    :param start_dt: <datetime> 起始日期
    :param end_dt: <datetime> 结束日期
    :param include: <bool> 是否包含入参start_dt和end_dt非月初月末，默认包含
    :return :<list<tuple(月起始日期，月结束日期)>>
    """
    month_ends = get_month_end(start_dt, get_month_end_by_dt(end_dt))
    month_ranges = []
    for _edt in month_ends:
        _sdt = datetime.datetime(_edt.year, _edt.month, 1)
        if _sdt < start_dt:
            if not include:
                continue
            _sdt = start_dt
        if _edt > end_dt:
            if not include:
                continue
            _edt = end_dt
        month_ranges.append((_sdt, _edt))
    return month_ranges


if __name__ == '__main__':
    # print(parse_d('2020-10-22'))
    # print(parse_dt('2020-10-22 10:22:00'))
    # print(fmt_dts((parse_dt('2020-10-22 10:22:00'), None, parse_d('2014-10-23')), '%Y%m%d'))

    # print(get_offset_year(parse_dt('2020-10-22 10:22:00'), -1))
    # print(get_offset_year_str('2020-11-02', -1))
    # print(get_week_monday(parse_d('2020-11-13')))
    # print(date_to_int(parse_d('2020-11-14')))
    # print(date_to_int('2020-11-15'))
    # print(date_to_int('2020/11/16'))
    # print(date_to_int(20201117))
    # print(get_quarter_end(pre_quarter_end(parse_d('2020-01-01')), pre_quarter_end(parse_d('2020-12-31'))))
    # print(year_start_dt(parse_d('2020-10-31')))
    # print(month_start_dt(parse_d('2020-10-31')))
    # print(is_quarter_end('2020-10-01'))
    # print(get_last_month_end('2020-12-31'))
    # print(get_month_end('2019-01-01', '2020-10-30'))
    print(get_rpt_day_list('2017-01-02', '2021-11-30'))
    # print(get_half_year_end('2019-01-01', '2020-10-30'))
    # print(get_year_end('2019-01-01', '2020-10-30'))
    # print(get_date_by_interval('2019-01-02', '2020-10-29', 'W', True))
    # print(get_month_end("2020-08-01", "2020-09-30"))
    # print(get_month_end_by_month('202102'))
    # print(get_month_end_by_month('20210228'))
    # print(get_month_end_by_month('20210227'))
    # print(split_to_month_range(parse_d('2020-01-22'), parse_d('2020-04-22'), include=True))
    # print(split_to_month_range(parse_d('2020-01-22'), parse_d('2020-04-22'), include=False))
    # print(split_to_month_range(parse_d('2020-01-22'), parse_d('2020-01-22'), include=True))



