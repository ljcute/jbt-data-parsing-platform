# -*- coding: utf-8 -*-
import hashlib
import numpy as np
import pandas as pd


def md5(val):
    if isinstance(val, str):
        str_val = val
    elif isinstance(val, set):
        val = list(val)
        val.sort()
        str_val = str(list(val))
    elif isinstance(val, list) or isinstance(val, np.ndarray):
        val.sort()
        str_val = str(list(val))
    elif isinstance(val, pd.Series):
        str_val = str(val.sort_values().tolist())
    else:
        str_val = str(val)
    return hashlib.md5(str_val.encode()).hexdigest()


def sha256(val):
    if isinstance(val, str):
        str_val = val
    elif isinstance(val, set):
        val = list(val)
        val.sort()
        str_val = str(list(val))
    elif isinstance(val, list) or isinstance(val, np.ndarray):
        val.sort()
        str_val = str(list(val))
    elif isinstance(val, pd.Series):
        str_val = str(val.sort_values().tolist())
    else:
        str_val = str(val)
    return hashlib.sha256(str_val.encode()).hexdigest()


def hash_code(s):
    """取长整型hash值，类似java hashCode函数"""
    h = 0
    n = len(s)
    for i, c in enumerate(s):
        h = h + ord(c) * 31 ** (n - 1 - i)
    bits = 64
    return (h + 2 ** (bits - 1)) % 2 ** bits - 2 ** (bits - 1)


def sha256_hash_code(val):
    return hash_code(sha256(val))


if __name__ == '__main__':
    osha256 = sha256('{"portf_code":1505831455799009283}')
    print(osha256)
    print(hash_code('hello,world'))
    print(hash_code(osha256))
    print(sha256_hash_code('hello, world'))
    print(md5('hello, world'))
    print(md5(['2', '5', '1', 'c', 'f', 'a', 'b']))
    print(md5(['a', 'b', '1', 'c', '2', '5', 'f']))
    print(md5({'a', 'b', '1', 'c', '2', '5', 'f'}))
    print(md5(np.array(['2', '5', '1', 'c', 'f', 'a', 'b'])))
    print(md5(np.array(['a', 'b', '1', 'c', '2', '5', 'f'])))
    print(md5(pd.Series(['2', '5', '1', 'c', 'f', 'a', 'b'])))
    print(md5(pd.Series(['a', 'b', '1', 'c', '2', '5', 'f'])))
