# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
from decimal import Decimal


def divide(divisor, dividend):
    """
    数字的除法，判断除数为0的场景，避免出现大量的运行时告警
    :param divisor:
    :param dividend:
    :return:
    """
    if dividend is None or dividend == 0:
        return np.NAN
    if divisor is None:
        return 0
    return np.divide(divisor, dividend)


def multiply(multiplier, multiplicand):
    """
    数字的乘法
    :param multiplier:
    :param multiplicand:
    :return:
    """
    if multiplier is None or multiplicand is None:
        return 0
    return np.multiply(multiplier, multiplicand)


def float_2_decimal(val, precision='0.00000000'):
    """
    浮点数转decimal，保留8位小数
    :param val: <float> 浮点数，非浮点数类型不处理
    :param precision: <str> 精确位数模式
    :return : <Decimal> 若入参为浮点数则返回Decimal，否则原值返回
    """
    return Decimal(str(val)).quantize(Decimal(precision)) if isinstance(val, float) or isinstance(val, int) else val


def floats_2_decimals(data, precision='0.00000000'):
    """
    浮点数转decimal，保留8位小数
    :param data: <pandas.Series|DataFrame> 含浮点数的序列或表格
    :param precision: <str> 精确位数模式
    :return : <pandas.Series|DataFrame>
    """
    if isinstance(data, pd.Series):
        return data.apply(lambda x: float_2_decimal(x, precision))
    elif isinstance(data, pd.DataFrame):
        return data.apply(lambda row: floats_2_decimals(row, precision), axis=1)
    return data


if __name__ == '__main__':
    print(divide(9, None) - 1)
    print(multiply(3, 4))
