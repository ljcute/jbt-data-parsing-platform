# -*- coding: utf-8 -*-
from os.path import abspath, realpath, dirname, join
import os


def create_file_if_not_exist(file_path):
    """
    创建指定文件，如果文件或目录不存在，则创建，否则静默通过
    :param file_path:
    :return:
    """
    import os
    if not os.path.exists(file_path):
        _dir = os.path.dirname(file_path)
        if not os.path.exists(_dir):
            os.makedirs(_dir)
        if not file_path.endswith('/'):
            if not os.path.isfile(file_path):
                with open(file_path, mode='w', encoding='utf-8'):
                    pass


def get_base_path():
    base_path = dirname(dirname(abspath(realpath(dirname(__file__)))))
    return base_path


def get_base_pre_path():
    """
    获取根目录上层目录
    :return:
    """
    base_path = dirname(dirname(abspath(join(realpath(dirname(__file__)), ".."))))
    return base_path


def get_file_data_path():
    base_path = get_base_path()
    return join(base_path, 'z_data')


def get_filepath(folder_path, filename):
    """
    获取存储文件名
    """
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    return os.path.join(folder_path, filename)


def valid_file(file_path):
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        return True
    return False


def delete_files(dir_name):
    """
    删除文件夹下所有文件，包含子文件夹文件
    :param dir_name:
    :return:
    """
    file_list = []
    if os.path.isfile(dir_name):
        file_list.append(dir_name)
    else:
        for root, dirs, files in os.walk(dir_name):
            for name in files:
                file_list.append(os.path.join(root, name))
    for file in file_list:
        os.remove(file)


def test_p_field():
    file = open("c:/1.txt")
    r = []
    while 1:
        line = file.readline()
        if not line:
            break
        if line.find('l_ratio') == -1:
            continue
        start = line.find('r.') + 2
        end = line.find('*')
        r.append(line[start:end].strip())
    return r


if __name__ == '__main__':
    # create_file_if_not_exist('F:/abc/efg/xyz.txt')
    # create_file_if_not_exist('F:/abc/efg/uvw/')
    # create_file_if_not_exist('F:/abc/efg/xyz.txt')
    # create_file_if_not_exist('F:/abc/efg/uvw/')
    # print(get_file_data_path())
    print(test_p_field())

