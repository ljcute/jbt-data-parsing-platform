import threading
from jspytool import logger


def new_locker():
    """
    创建一个多线程锁，用法示例：
    locker = new_locker()
    try:
        locker.acquire()  # 加锁
        # 操作非线程安全的共享资源...
        locker.release()  # 释放锁
    except Exception as ex:
        locker.release()  # 异常释放锁
    """
    return threading.Lock()


class RetFuncExecThread(threading.Thread):
    """
    带返回值的函数执行线程
    """
    def __init__(self, func, params, kw=None, lock=None, ret_arr=None):
        threading.Thread.__init__(self)
        self.func = func
        self.params = params if params else ()
        self.kw = kw if kw else {}
        self.ret = None
        self.ex = None
        self.lock = lock
        self.ret_arr = ret_arr

    def run(self):
        try:
            self.ret = self.func(*self.params, **self.kw)
        except Exception as ex:
            self.ex = ex
            logger.error(f"线程执行异常：{ex}", exc_info=True)
        if self.lock is not None and self.ret_arr is not None:
            self.lock.acquire()
            self.ret_arr.append(self.ret)
            self.lock.release()

    def get_params(self):
        return self.params

    def get_ret(self):
        return self.ret

    def get_ex(self):
        return self.ex
