# -*- coding: utf-8 -*-


class BizException(Exception):

    def __init__(self, msg='服务异常', code='5000'):
        Exception.__init__(self)
        self.msg = msg
        self.code = code

    def to_dict(self):
        return {"code": self.code, "msg": self.msg}


def register_exception_handler(blueprint):
    """
    注册蓝本全局异常处理
    :param blueprint:
    :return:
    """
    from flask import jsonify

    @blueprint.errorhandler(BizException)
    def handle_biz_exception(ex):
        from flask import current_app as app
        _dict = ex.to_dict()
        res = jsonify(_dict)
        app.logger.error('业务异常，code=%s，msg=%s' % (_dict['code'], _dict['msg']), exc_info=True)
        return res

    @blueprint.errorhandler(Exception)
    def handle_exception(ex):
        from flask import current_app as app
        _dict = {"code": "5000", "msg": f"服务非预期异常，error：{ex}"}
        res = jsonify(_dict)
        app.logger.error('运行异常，code=%s，msg=%s' % (_dict['code'], _dict['msg']), exc_info=True)
        return res
