# -*- coding: utf-8 -*-
import numpy as np


def gen_ora_in_placeholder(param_len, start=1):
    """
    拼接Oracle IN 语句的参数占位符，例如：:2,:3,:4
    :param param_len: IN元素个数
    :param start: 初始占位符索引
    :return:
    """
    _p_arr, i = [], start
    for j in range(param_len):
        _p_arr.append(':%d' % i)
        i = i + 1
    _place_holder = ','.join(_p_arr)
    return _place_holder


def gen_mysql_in_placeholder(param_len):
    """
    拼接MySQL IN 语句的参数占位符，例如：%s,%s,%s
    :param param_len: IN元素个数
    :return:
    """
    _p_arr = ('%s' for i in range(param_len))
    _place_holder = ','.join(_p_arr)
    return _place_holder


def replace_nan(data):
    """
    二维数组中，nan，inf替换成None，建议在批量写库之前进行该处理
    """
    _data = []
    for _row in data:
        _arr = []
        for i in _row:
            _arr.append(None if type(i) == float and (np.isnan(i) or np.isinf(i)) else i)
        _data.append(_arr)
    return _data


if __name__ == '__main__':
    # print(gen_mysql_in_placeholder(4))
    print(gen_ora_in_placeholder(105, 1))
    # print(gen_ora_in_placeholder(4, 2))
