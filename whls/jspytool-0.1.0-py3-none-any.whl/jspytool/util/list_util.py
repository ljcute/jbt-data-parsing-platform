# -*- coding: utf-8 -*-
import math


def split_list(origin_list, n):
    """
    按n数量将orgin_list分割成多个list，返回的是一个数组
    :param origin_list:
    :param n:
    :param new_list:
    :return:
    """
    new_list = []
    if len(origin_list) <= n:
        new_list.append(origin_list)
        return new_list

    # 计算分割的数组个数
    _size = math.ceil(len(origin_list) / n)
    for i in range(_size):
        if i < _size - 1:
            new_list.append(origin_list[i * n: (i + 1) * n])
        elif i == _size - 1:
            new_list.append(origin_list[i * n: len(origin_list)])
    return new_list


def list_diff(list_a, list_b):
    """list_a-list_b的差集"""
    return list(set(list_a).difference(set(list_b)))


