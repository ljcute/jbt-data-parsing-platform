# -*- coding: utf-8 -*-
import inspect
import hashlib
import importlib
import datetime


def dynamic_invoke(module, method, args, kwargs):
    # 动态引入模块
    mod = importlib.import_module(module)

    # 动态调用函数
    func = eval('mod.' + method)
    if args and kwargs:
        res = func(*args, **kwargs)
    elif args and not kwargs:
        res = func(*args)
    elif kwargs and not args:
        res = func(**kwargs)
    else:
        res = func()

    return res


def make_func_invoke_key(func, args, kwargs, marker, typed, prefix):
    kwargs = kwargs.copy()
    key_args = (func.__name__,)

    # Normalize args by moving positional arguments passed in as keyword arguments from
    # kwargs into args. This is so functions like foo(a, b, c) called with
    # foo(1, b=2, c=3) and foo(1, 2, 3) and foo(1, 2, c=3) will all have the same cache
    # key.
    if kwargs:
        arg_spec = inspect.getfullargspec(func)
        for i, arg in enumerate(arg_spec.args):
            if arg in kwargs:
                args = args[:i] + (kwargs.pop(arg),) + args[i:]

    if args:
        key_args += args

    if kwargs:
        # Separate args and kwargs with marker to avoid ambiguous cases where args
        # provided might look like some other args+kwargs combo.
        key_args += marker
        key_args += tuple(sorted(kwargs.items()))

    if typed and args:
        key_args += tuple(type(arg) for arg in args)

    if typed and kwargs:
        key_args += tuple(type(val) for _, val in sorted(kwargs.items()))

    # Hash everything in key_args and concatenate into a single byte string.
    raw_key = b"".join(
        map(lambda v: str(v).encode(), (str(arg) for arg in key_args))
    )

    # Combine prefix with md5 hash of raw key so that keys are normalized in length.
    return prefix + hashlib.md5(raw_key).hexdigest()


def flat_func_param(func, args, kwargs, fmt_dt=False):
    """
    将函数**kw参数打平成args
    :param func: <Function> 函数
    :param args: <tuple> 函数元组参数
    :param kwargs: <dict> 函数字典参数
    :param fmt_dt: <bool> 是否格式化无时分秒的datetime类型
    :return: <tuple> 打平成元组的参数
    """
    arg_spec = inspect.getfullargspec(func)
    args = () if args is None else args
    kwargs = {} if kwargs is None else kwargs
    _defaults = [] if arg_spec.defaults is None else arg_spec.defaults
    if len(args) == 0 and len(kwargs) == 0:
        return args

    # 提取默认参数dict
    _di = len(arg_spec.args) - len(_defaults)
    _dn = arg_spec.args[_di:]
    _dkw = {}
    for i, n in enumerate(_dn):
        _dkw[n] = _defaults[i]
    # 默认参数dict与用户传入dict合并
    _kwargs = kwargs.copy()
    _kwargs = {**_dkw, **_kwargs}

    size = len(args)
    for i, arg in enumerate(arg_spec.args):
        # 填充默认参数
        if i >= size:
            args = args[:i] + (_kwargs.get(arg),)
    args = (process_arg(i, fmt_dt) for i in args)

    return args


def process_arg(arg, fmt_dt=False):
    # 如果参数类型为datetime，且时分秒为0，则格式化为：%Y-%m-%d
    if fmt_dt and isinstance(arg, datetime.datetime) and arg.hour == arg.minute == arg.second == 0:
        return arg.strftime('%Y-%m-%d')
    return arg
