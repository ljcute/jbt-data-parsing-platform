# -*- coding: utf-8 -*-
import requests
import random
import threading
import time
import copy
import yaml
from requests.adapters import HTTPAdapter
from jspytool import logger

"""
服务初始化步骤：
1，从nacos加载应用配置，更新full_cfg字典对象；
2，从nacos加载配置中依赖的微服务健康实例，并初始化http连接池；
3，注册当前服务到nacos；
4，启动定时任务：间隔35秒钟刷新依赖的微服务健康实例；
5，启动定时任务，间隔4秒发送心跳，发送心跳之前先检查当前服务是否健康状态，若非健康状态，则需要重新注册服务实例，最后再发送心跳
"""

__all__ = ['load_configuration', 'load_microservices', 'get_session', 'send_heart_beat', 'get', 'post_json']

locker = threading.RLock()
# 全量配置
full_cfg = {'nacos': {}}
# 微服务会话列表
ms_session_map = {}


# 从nacos加载配置
def load_configuration(nacos_cfg):
    """
    初始化nacos服务配置
    :param nacos_cfg:<dict> nacos配置格式如下，
    {
          server_addr: 172.16.10.127:8848
          namespace: fat
          group: DEFAULT_GROUP
          # 启用nacos中心化配置
          data_id: jspy-pra-service.yaml
          # 启用微服务，往nacos注册IP和端口（适用docker）
          register_service_name: jspy-pra-service
          register_ip: 172.16.10.48
          register_port: 3002
    }
    :return: 全量配置
    """
    global full_cfg
    data_id = nacos_cfg.get('data_id')
    if data_id:
        server_addr = nacos_cfg['server_addr']
        namespace = nacos_cfg['namespace']
        group = nacos_cfg.get('group', 'DEFAULT_GROUP')
        url = f'http://{server_addr}/nacos/v1/cs/configs?tenant={namespace}&dataId={data_id}&group={group}'
        res = requests.get(url)
        _cfg = yaml.load(res.text, yaml.FullLoader)
        # 更新到全局配置对象
        full_cfg.update(_cfg)
        # 补充nacos服务配置
        full_cfg['nacos'] = nacos_cfg
        return copy.deepcopy(full_cfg)
    raise ValueError(f'参数nacos_cfg缺少data_id属性，无法从配置中心加载配置!nacos_cfg={nacos_cfg}')


# 加载微服务实例列表
def load_microservices(ms_client_dict=None):
    global ms_session_map
    if ms_client_dict is None:
        ms_client_dict = full_cfg.get('microservices', {})
    # 1. 加载新服务session
    new_session_map = {}
    for short_service_name, conf in ms_client_dict.items():
        sessions = []
        # 判断是否从注册中心
        lb_prefix = 'lb://'
        if conf['uri'].startswith(lb_prefix):
            server_addr = full_cfg['nacos']['server_addr']
            namespace = full_cfg['nacos']['namespace']
            group_name = full_cfg['nacos'].get('group', 'DEFAULT_GROUP')
            full_service_name = conf['uri'].replace(lb_prefix, '')
            service_hosts = list_instance(server_addr, namespace, full_service_name, group_name)
            for h in service_hosts:
                session = requests.Session()
                session.ms_uri = f"http://{h['ip']}:{h['port']}{conf.get('web_context', '')}"
                session.mount(session.ms_uri,
                              HTTPAdapter(pool_connections=conf.get('pool_connections', 3),
                                          pool_maxsize=conf.get('pool_maxsize', 100),
                                          max_retries=conf.get('max_retries', 3)))
                sessions.append(session)
        else:
            session = requests.Session()
            session.ms_uri = conf['uri'] + conf.get('web_context', '')
            session.mount(session.ms_uri,
                          HTTPAdapter(pool_connections=conf.get('pool_connections', 3),
                                      pool_maxsize=conf.get('pool_maxsize', 100),
                                      max_retries=conf.get('max_retries', 3)))
            sessions.append(session)
        new_session_map[short_service_name] = sessions
    # 2. 替代旧服务session
    old_session_map = ms_session_map
    with locker:
        ms_session_map = new_session_map
    # 3. 销毁旧服务session
    for service_name, sessions in old_session_map.items():
        for session in sessions:
            session.close()
    # 每隔10分钟打印一次日志
    _min = time.localtime(time.time()).tm_min
    if _min in (0, 10, 20, 30, 40, 50):
        logger.info('完成微服务实例列表刷新')


# 获取指定微服务地址（带上下文）
def get_session(service_name):
    with locker:
        sessions = ms_session_map.get(service_name)
        if sessions is None or len(sessions) == 0:
            raise Exception(f'微服务[{service_name}]暂不可用，请检查服务是否启动')
        # 随机选取一个健康实例
        return sessions[random.randint(0, len(sessions) - 1)]


# 从nacos服务获取健康的实例列表
def list_instance(server_addr, namespace, service_name, group_name='DEFAULT_GROUP'):
    """
    查询服务实例列表，返回健康实例
    :return :<list<dict>> 示例：
    [{"ip": "10.31.35.20", "port": 9021}]
    """
    url = f'http://{server_addr}/nacos/v1/ns/instance/list?groupName={group_name}&namespaceId={namespace}' \
          f'&healthyOnly=true&serviceName={service_name}'
    response = requests.get(url)
    hosts = response.json()['hosts']
    return hosts


# 查询实例详情
def get_instance_detail(server_addr, namespace, service_name, ip, port, group_name='DEFAULT_GROUP'):
    """
    查询实例详情
    :return :<dict> 示例：{"service":"xxx","ip":"10.31.30.43","port":3002,"weight":1.0,"healthy":true}
    """
    url = f'http://{server_addr}/nacos/v1/ns/instance?serviceName={service_name}&groupName={group_name}' \
          f'&namespaceId={namespace}&ip={ip}&port={port}&healthyOnly=true'
    res = requests.get(url)
    if res.status_code == 200:
        # logger.info('查询实例详情，response：%s' % res.text)
        return res.json().get('healthy', False)
    else:
        logger.warning('查询实例详情失败，msg：%s' % res.text)
        return False


# 注册当前服务到nacos
def register_instance():
    if not full_cfg['nacos'].get('register_service_name'):
        return False
    server_addr = full_cfg['nacos']['server_addr']
    namespace = full_cfg['nacos']['namespace']
    group_name = full_cfg['nacos'].get('group', 'DEFAULT_GROUP')
    service_name = full_cfg['nacos']['register_service_name']
    ip = full_cfg['nacos']['register_ip']
    port = full_cfg['nacos']['register_port']
    url = f'http://{server_addr}/nacos/v1/ns/instance?ip={ip}&port={port}&serviceName={service_name}' \
          f'&groupName={group_name}&namespaceId={namespace}&healthy=true&enabled=true'
    res = requests.post(url)
    logger.info('注册服务实例，msg：%s' % res.text)
    return True if 'ok' == res.text else False


# 发送心跳到nacos，维持健康状态
def send_heart_beat():
    if not full_cfg['nacos'].get('register_service_name'):
        return False
    server_addr = full_cfg['nacos']['server_addr']
    namespace = full_cfg['nacos']['namespace']
    group = full_cfg['nacos'].get('group', 'DEFAULT_GROUP')
    service_name = full_cfg['nacos']['register_service_name']
    ip = full_cfg['nacos']['register_ip']
    port = full_cfg['nacos']['register_port']
    # 先查询实例是否健康
    instance = get_instance_detail(server_addr, namespace, service_name, ip, port, group)
    if not instance:
        register_instance()
    url = f'http://{server_addr}/nacos/v1/ns/instance/beat?ip={ip}&port={port}&serviceName={service_name}' \
          f'&namespaceId={namespace}&groupName={group}'
    res = requests.put(url)
    # logger.info('发送心跳，res：%s' % res.text)
    # 每隔10分钟打印一次日志
    _min = time.localtime(time.time()).tm_min
    if _min in (0, 10, 20, 30, 40, 50):
        logger.info('发送心跳成功，res：%s' % res.text)
    return res.json()


def get(ms_name, uri, params=None):
    """
    GET请求指定微服务
    :param ms_name:<str> 微服务名称，即在nacos注册的服务ID
    :param uri:<str> 请求资源URI，不包含hostname和context，例如：/ms/common/id/gen
    :param params:<dict> querystring参数
    :return :<dict> 响应一个字典对象
    """
    session = get_session(ms_name)
    url = f'{session.ms_uri}{uri}'
    res = session.get(url, params=params)
    if res.status_code != 200:
        logger.error(f'请求服务[{ms_name}]异常，uri={uri}，response={res.text}', exc_info=True)
        raise Exception(res.text)
    if res.text:
        try:
            return res.json()
        except Exception as ex:
            logger.error(f'请求服务[{ms_name}]异常，uri={uri}，response={res.text}，error={ex}', exc_info=True)
            raise ex
    else:
        return None


def post_json(ms_name, uri, json=None):
    """
    POST JSON请求指定微服务
    :param ms_name:<str> 微服务名称，即在nacos注册的服务ID
    :param uri:<str> 请求资源URI，不包含hostname和context，例如：/ms/common/id/gen
    :param json:<obj> 请求对象
    :return :<dict> 响应一个字典对象
    """
    session = get_session(ms_name)
    url = f'{session.ms_uri}{uri}'
    res = session.post(url, json=json)
    if res.status_code != 200:
        logger.error(f'请求服务[{ms_name}]异常，uri={uri}，json={json}，response={res.text}', exc_info=True)
        raise Exception(res.text)
    if res.text:
        try:
            return res.json()
        except Exception as ex:
            logger.error(f'请求服务[{ms_name}]异常，uri={uri}，json={json}，response={res.text}，error={ex}', exc_info=True)
            raise ex
    else:
        return None

